package com.Rest.Rest1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
public class EmpController {
    @Autowired
    private EmpDauService service;

    //Ques3
    @GetMapping("/employees")
    public List<Emp> retrieveAllEmployees() {
        return service.findAll();
    }

    //Ques4
    @GetMapping("employees/{id}")
    public Emp retrieveUser(@PathVariable int id) {
        Emp employeeBean = service.findOne(id);

        if (employeeBean == null)
            throw new EmpEx("id" + id);
        return employeeBean;

    }


    //Ques5
    @PostMapping("/employees")
    public ResponseEntity<Object> createEmployee(@Valid  @RequestBody Emp employeeBean) {
        Emp addemp = service.save(employeeBean);
        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/id")
                .buildAndExpand(addemp.getId()).toUri();

        return ResponseEntity.created(location).build();
    }

    //Ques7
    @DeleteMapping("/employees/{id}")
    public Emp deleteEmployee(@PathVariable int id) {
        Emp employeeBean = service.deleteOne(id);
        if (employeeBean == null)
            throw new EmpEx("id-" + id);
        return employeeBean;
    }

    //Ques8
    @PutMapping("/employees/{id}")
    public Emp updateEmployee(@PathVariable Integer id, @RequestBody Emp employee) {
        Emp employeeBean = service.findOne(id);
        if (employeeBean == null)
            throw new EmpEx("id-" + id);

        else {
            if (employee.getId() != null) {
                employeeBean.setId(employee.getId());
            }

            if (employee.getName() != null) {
                employeeBean.setName(employee.getName());
            }
            if (employee.getAge() != null) {
                employeeBean.setAge(employee.getAge());
            }
        }
        return employeeBean;
    }
}