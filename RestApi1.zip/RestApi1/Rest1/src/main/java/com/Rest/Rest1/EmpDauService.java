package com.Rest.Rest1;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Repository
public class EmpDauService {

        private static List<Emp> emp=new ArrayList<>();
        private static int empCount=3;

        static {
            emp.add(new Emp(1,"Ayush",21));
        }


        public List<Emp> findAll(){
            return emp;
        }


        public Emp save(Emp employeeBean){
            if(employeeBean.getId()==null){
                employeeBean.setId(++empCount);
            }
            emp.add(employeeBean);
            return employeeBean;
        }


        public Emp findOne(int id){
            for(Emp employeeBean:emp){
                if(employeeBean.getId()==id){
                    return employeeBean;
                }
            }
            return null;
        }


        public Emp deleteOne(int id){
            Iterator<Emp> iterator=emp.iterator();
            while (iterator.hasNext()){
                Emp employeeBean=iterator.next();
                if(employeeBean.getId()==id){
                    iterator.remove();
                    return employeeBean;
                }
            }
            return null;
        }
}
