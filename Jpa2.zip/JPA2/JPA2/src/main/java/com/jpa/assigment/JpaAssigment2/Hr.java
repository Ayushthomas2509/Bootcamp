package com.jpa.assigment.JpaAssigment2;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue("hr")
@Table(name = "hr")
@PrimaryKeyJoinColumn(name = "E_id",referencedColumnName = "id")
public class Hr extends Employee {
    private String deptName="HR";

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

}
