package com.jpa.assigment.JpaAssigment2;

import javax.persistence.Embeddable;

@Embeddable
public class Salary {

private int basicSalary;
private int bonusSalary;
private int tax;
private int spAllowanceSalary;

    public int getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(int basicSalary) {
        this.basicSalary = basicSalary;
    }

    public int getBonusSalary() {
        return bonusSalary;
    }

    public void setBonusSalary(int bonusSalary) {
        this.bonusSalary = bonusSalary;
    }

    public int getTax() {
        return tax;
    }

    public void setTax(int tax) {
        this.tax = tax;
    }

    public int getSpAllowanceSalary() {
        return spAllowanceSalary;
    }

    public void setSpAllowanceSalary(int spAllowanceSalary) {
        this.spAllowanceSalary = spAllowanceSalary;
    }
}
