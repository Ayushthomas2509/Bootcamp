package com.jpa.assigment.JpaAssigment1;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@SpringBootTest
class JpaAssigment1ApplicationTests {
	@Autowired
EmployeeRepo employeeRepo;
	@Test
	void contextLoads() {
	}

	@Test
	void create() {

			Employee employee = new Employee();
			employee.setName("Kartik");
			employee.setAge(21);
			employee.setLocation("Faridabad");
			employeeRepo.save(employee);

	}
	@Test
	void update(){
		Employee currentEmployee=employeeRepo.findById(1).get();
		currentEmployee.setAge(18);
		employeeRepo.save(currentEmployee);
	}
	@Test
	void read(){
		System.out.println("Emp="+employeeRepo.findById(1).get().getName());
	}
	@Transactional
	@Test
	void delete() {
		employeeRepo.deleteById(1);
	}
	@Test
	void count(){
		System.out.println("Count="+employeeRepo.count());
	}

	@Test
	void addMore() {
		Employee employee = new Employee();
		employee.setName("Thomas");
		employee.setAge(23);
		employee.setLocation("Delhi");
		employeeRepo.save(employee);
	}



	@Test
	void findall(){
		System.out.println(employeeRepo.findAll().toString());
	}
	@Test
	void sort(){

		Pageable pageable=PageRequest.of(0, 3, Sort.by(Sort.Direction.DESC,"age"));
		Page<Employee> page = employeeRepo.findAll(pageable);
		page.forEach(p -> System.out.println(p.toString()));
	}
	@Test
	void find() {
		System.out.println(employeeRepo.findByName("Kartik"));
	}
	@Test
	void like() {
		System.out.println(employeeRepo.findByNameLike("t%"));
	}
	@Test
	void ageBt() {
		System.out.println(employeeRepo.findByAgeBetween(10,20));
	}
}
