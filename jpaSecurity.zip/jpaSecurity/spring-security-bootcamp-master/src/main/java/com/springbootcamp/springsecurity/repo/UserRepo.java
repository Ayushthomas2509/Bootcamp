package com.springbootcamp.springsecurity.repo;

import com.springbootcamp.springsecurity.User;
import org.springframework.data.repository.CrudRepository;

public interface UserRepo  extends CrudRepository<User,String> {
}
