package com.springbootcamp.springsecurity;

import com.springbootcamp.springsecurity.repo.UserRepo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

@SpringBootTest
class SpringSecurityApplicationTests {

	PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();



	@Autowired
	UserRepo userRepo;
	@Test
	void contextLoads() {

		User user = new User("A", passwordEncoder.encode("pass"),null);
		user.setAuth("ROLE_USER");
		userRepo.save(user);
	}

}
