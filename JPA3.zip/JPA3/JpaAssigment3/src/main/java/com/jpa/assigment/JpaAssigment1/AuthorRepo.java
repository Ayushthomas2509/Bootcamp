package com.jpa.assigment.JpaAssigment1;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

@EnableJpaRepositories
public interface AuthorRepo extends CrudRepository<Author,Integer> {

}
