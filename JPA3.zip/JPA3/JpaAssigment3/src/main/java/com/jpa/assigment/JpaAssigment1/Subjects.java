package com.jpa.assigment.JpaAssigment1;

import org.springframework.stereotype.Service;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import java.util.List;

@Embeddable
public class Subjects {
    private String sub1;
    private String sub2;
    private String sub33;


    public String getSub1() {
        return sub1;
    }

    public void setSub1(String sub1) {
        this.sub1 = sub1;
    }

    public String getSub2() {
        return sub2;
    }

    public void setSub2(String sub2) {
        this.sub2 = sub2;
    }

    public String getSub33() {
        return sub33;
    }

    public void setSub33(String sub33) {
        this.sub33 = sub33;
    }
}
