package com.springbootcampjpa;

import com.springbootcampjpa.Student.Student;
import com.springbootcampjpa.Student.StudentRepositary;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootcampJpaDemo1ApplicationTests {

 @Autowired
 StudentRepositary repositary;
//	@Autowired
//	PaymentRepositary paymentRepositary;

//	@Autowired
//	CustomerRepositary customerRepositary;
	//@Test
//	void contextLoads() {
//	}
	@Test
	public void testStudent(){
		Student student=new Student();
		student.setFName("Ayush");
		student.setLname("Thomas");
		student.setScore(90);
//
//		Student student2=new Student();
//		student2.setFName("Gunjan");
//		student2.setLname("Dawar");
//		student2.setScore(95);
//
//		Student student3=new Student();
//		student3.setFName("Kartik");
//		student3.setLname("Kumar");
//		student3.setScore(60);
		repositary.save(student);
//		repositary.save(student2);
//		repositary.save(student3);

	}
//	@Test
//	public void find(){
		//System.out.println(repositary.findAllStudents().toString());
//		System.out.println(repositary.findAllStudents(PageRequest.of(0,7, Sort.Direction.ASC,"id")).toString());

//	}
//	@Test
//	public void findNative(){
//		System.out.println(repositary.findAllNative(PageRequest.of(0,5, Sort.Direction.ASC,"id")));
//	}

//@Test
//	public void cardpayment(){
//	CreditCard creditCard = new CreditCard();
//	//creditCard.setId();
//	creditCard.setAmount(20000);
//	creditCard.setCreditcard("1234Abcdse");
//
//	paymentRepositary.save(creditCard);
//}
//@Test
//	public void chequepayment(){
//	Cheque cheque = new Cheque();
//	cheque.setAmount(10000);
//	cheque.setCheque("901342556");
//
//	paymentRepositary.save(cheque);
//}

//	@Test
	public void customercreate(){
	   Customer customer = new Customer();
	   customer.setName("Ayush");
	HashSet<PhoneNumber> numbers = new HashSet<>();
	PhoneNumber PhoneNumber = new PhoneNumber();
	PhoneNumber.setNumber("981112233");
	PhoneNumber.setType("Mobile Phone");
	numbers.add(PhoneNumber);
	customer.setNumbers(numbers);



	customerRepositary.save(customer);
//}
}
