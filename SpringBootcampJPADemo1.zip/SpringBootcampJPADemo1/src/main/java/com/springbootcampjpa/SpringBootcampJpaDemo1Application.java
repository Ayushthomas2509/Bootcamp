package com.springbootcampjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootcampJpaDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootcampJpaDemo1Application.class, args);
	}

}
