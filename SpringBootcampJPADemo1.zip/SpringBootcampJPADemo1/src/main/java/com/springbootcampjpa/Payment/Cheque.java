package com.springbootcampjpa.Payment;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ch")
public class Cheque extends payment {
    String cheque;

    public String getCheque() {
        return cheque;
    }

    public void setCheque(String cheque) {
        this.cheque = cheque;
    }

    @Override
    public String toString() {
        return "Cheque{" +
                "cheque='" + cheque + '\'' +
                '}';
    }
}
