package com.springbootcampjpa.Payment;

import org.springframework.data.repository.CrudRepository;

public interface PaymentRepositary extends CrudRepository<payment,Integer> {

}
