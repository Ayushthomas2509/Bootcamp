package com.springbootcampjpa.Employee;

import javax.persistence.*;

@Entity
public class Employee {
//    @Embedded
//    Address address;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    String name;


}
