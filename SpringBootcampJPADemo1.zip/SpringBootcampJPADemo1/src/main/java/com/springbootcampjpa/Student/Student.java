package com.springbootcampjpa.Student;

import javax.persistence.*;

@Entity
@Table(name = "student")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "fname")
    String Fname;
    @Column(name = "lname")
    String Lname;
    Integer score;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFName() {
        return Fname;
    }

    public void setFName(String fname) {
        this.Fname = fname;
    }

    public String getLname() {
        return Fname;
    }

    public void setLname(String lname) {
        this.Lname = lname;
    }

    public Integer getScore() {
        return score;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", Fname='" + Fname + '\'' +
                ", Lname='" + Lname + '\'' +
                ", score=" + score +
                '}';
    }

    public void setScore(Integer score) {
        this.score = score;
    }


}
