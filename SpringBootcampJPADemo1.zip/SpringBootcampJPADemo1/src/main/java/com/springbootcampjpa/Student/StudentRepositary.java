package com.springbootcampjpa.Student;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface StudentRepositary extends CrudRepository<Student,Integer> {

 //@Query("from Student")
 //List<Student> findAllStudents();

 //Paging And Sorting
 @Query("from Student")
 List<Student> findAllStudents(PageRequest pageRequest);
//Native Queries
// @Query(value = "select * from student",nativeQuery = true)
 //List<Student> findAllNative();
 //Paging in Native
 @Query(value = "select * from student",nativeQuery = true)
 List<Student> findAllNative(PageRequest pageRequest);

}
