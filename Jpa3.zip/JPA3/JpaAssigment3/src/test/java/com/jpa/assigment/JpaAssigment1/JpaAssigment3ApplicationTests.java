package com.jpa.assigment.JpaAssigment1;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@SpringBootTest
class JpaAssigment3ApplicationTests {
	@Autowired
	AuthorRepo authorRepo;
//	@Test
//	void contextLoads() {
//	}

	@Test
	void create() {

			Author author = new Author();
			author.setName("Ayush");

			Address address=new Address();
			address.setStreetNumber(21);
			address.setLocation("Rohini");
			address.setState("Delhi");
			author.setAddress(address);

			Subjects subjects=new Subjects();
			subjects.setSub1("English");
			subjects.setSub2("French");
			subjects.setSub33("German");
			author.setSubjects(subjects);

			authorRepo.save(author);

	}

	@Test
	void oneToOne() {

		Author author = new Author();
		author.setName("Kartik");
		Address address=new Address();
		address.setStreetNumber(21);
		address.setLocation("Faridabad");
		address.setState("Haryana");
		author.setAddress(address);

		Subjects subjects=new Subjects();
		subjects.setSub1("English");
		subjects.setSub2("French");
		subjects.setSub33("German");
		author.setSubjects(subjects);

		Book book=new Book();
		book.setBookName("ice and fire");
//		book.setAuthors(author);
//		author.setBooks(book);



		authorRepo.save(author);

	}

	@Test
	void oneToMany() {

		Author author = new Author();
		author.setName("Ayush");
		Address address=new Address();
		address.setStreetNumber(21);
		address.setLocation("Faridabad");
		address.setState("Haryana");
		author.setAddress(address);

		Subjects subjects=new Subjects();
		subjects.setSub1("English");
		subjects.setSub2("French");
		subjects.setSub33("German");
		author.setSubjects(subjects);

		List<Book> books=new LinkedList<>();
		Book book=new Book();
		book.setBookName("ice and fire");
		//book.setAuthor(author);
		books.add(book);
		Book book1=new Book();
		book1.setBookName("A Dream of Spring");
		//book1.setAuthor(author);
		books.add(book1);

		author.setBooks(books);


		authorRepo.save(author);

	}

	@Test
	void manyToMany() {

		Author author = new Author();
		author.setName("Ayush");
		Address address=new Address();
		address.setStreetNumber(21);
		address.setLocation("Rohini");
		address.setState("Delhi");
		author.setAddress(address);

		Subjects subjects=new Subjects();
		subjects.setSub1("English");
		subjects.setSub2("French");
		subjects.setSub33("German");
		author.setSubjects(subjects);

		List<Author> authors=new LinkedList<>();
		authors.add(author);
		List<Book> books=new LinkedList<>();
		Book book=new Book();
		book.setBookName("ice and fire");
		//book.setAuthors(authors);
		books.add(book);

		author.setBooks(books);

		authorRepo.save(author);

	}
}
