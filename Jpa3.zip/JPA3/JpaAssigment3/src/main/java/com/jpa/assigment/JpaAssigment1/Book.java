package com.jpa.assigment.JpaAssigment1;

import javax.persistence.*;
import java.util.List;

@Entity

public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String bookName;

    //@OneToOne
    //@JoinColumn(name = "authorId")
    //private Author author;

    //@ManyToMany(mappedBy = "books")
    //private List<Author> authors;

   // @ManyToOne
    //@JoinColumn(name = "authorId")
    //private Author author;

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

   // public List<Author> getAuthors() {
     //   return authors;
    //}

    //public void setAuthors(List<Author> authors) {
      //  this.authors = authors;
    //}


//    public Author getAuthor() {
//        return author;
//    }

//    public void setAuthor(Author author) {
//        this.author = author;
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
