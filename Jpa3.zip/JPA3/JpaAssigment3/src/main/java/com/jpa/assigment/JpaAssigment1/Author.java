package com.jpa.assigment.JpaAssigment1;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "author")
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String Name;
    @Embedded
    private Subjects subjects;
    @Embedded
    private Address address;
    //@OneToOne(mappedBy = "author",cascade = CascadeType.ALL)
    //private Book book;

    //@ManyToMany(cascade = CascadeType.ALL)
    //@JoinTable(name = "authorBook",joinColumns =@JoinColumn(name = "authorId",referencedColumnName = "id"),inverseJoinColumns =@JoinColumn(name = "bookId",referencedColumnName = "id") )

  //Add mapped by author
    // for bidirectional
    @OneToMany(cascade = CascadeType.ALL)
    private List<Book> books;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Subjects getSubjects() {
        return subjects;
    }

    public void setSubjects(Subjects subjects) {
        this.subjects = subjects;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
