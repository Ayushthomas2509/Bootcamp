package com.jpa.assigment.JpaAssigment2;

import com.jpa.assigment.JpaAssigment2.Employee;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface EmbededEmployeeRepo extends CrudRepository<EmbededEmployee,Integer> {


}
