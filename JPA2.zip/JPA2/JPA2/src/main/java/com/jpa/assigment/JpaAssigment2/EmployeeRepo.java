package com.jpa.assigment.JpaAssigment2;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface EmployeeRepo extends CrudRepository<Employee,Integer> {

    @Query("from Employee")
    List<Employee> findallemp();

    @Query("Select FirstName,LastName from Employee where salary>(select avg(salary) from Employee)")
    List<Object[]> findpar(Pageable pageable);

    @Query("select avg(salary) from Employee")
    int avgsal();

    @Query("select min(salary) from Employee")
    int minSal();
    @Modifying
    @Query("update Employee set salary=:newsal where salary<:avgsal")
    void salUpdate(@Param("newsal") int newsal,@Param("avgsal") int avgsal);

    @Modifying
    @Query("delete from Employee where salary=:minSal")
    void remEmp(@Param("minSal") int minSal);


    @Query(value = "select id,first_name,age from employee where last_name=:lastname",nativeQuery = true)
    List<Object[]>  native1(@Param("lastname") String lastname);

    @Modifying
    @Query(value = "delete from employee where age>:age",nativeQuery = true)
    void native2(@Param("age") int age);

}
