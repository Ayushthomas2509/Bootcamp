package com.jpa.assigment.JpaAssigment2;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class JpaAssigment2ApplicationTests {
	@Autowired
	EmployeeRepo employeeRepo;

	@Autowired
	EmbededEmployeeRepo embededEmployeeRepo;

	@Test
	void contextLoads() {
	}

	@Test
	void findall() {
		System.out.println(employeeRepo.findallemp());
	}

	@Test
	void jpql1() {


		for (Object[] objects : employeeRepo.findpar(PageRequest.of(0, 5, Sort.by("age").and(Sort.by("FirstName").descending())))) {
			System.out.println(objects[0] + " " + objects[1]);

		}
	}

	@Transactional
	@Rollback(false)
	@Test
	void jpql2() {
		employeeRepo.salUpdate(2000, employeeRepo.avgsal());
	}

	@Transactional
	@Test
	void jpq3() {
		int minSal = employeeRepo.minSal();
		employeeRepo.remEmp(minSal);
	}

	@Test
	void native1() {
		for (Object[] objects : employeeRepo.native1("singh")) {
			System.out.println(objects[0] + " " + objects[1] + " " + objects[2]);
		}
	}

	@Transactional
	@Test
	void native2() {
		employeeRepo.native2(45);
	}

	@Test
	void embedd() {
		EmbededEmployee employee1 = new EmbededEmployee();
		employee1.setFirstName("Kartik");
		employee1.setLastName("Kumar");
		employee1.setAge(21);

		Salary salary = new Salary();
		salary.setBasicSalary(10000);
		salary.setBonusSalary(2323);
		salary.setSpAllowanceSalary(322);
        salary.setTax(100);
		employee1.setSalary(salary);

		embededEmployeeRepo.save(employee1);

	}
}
