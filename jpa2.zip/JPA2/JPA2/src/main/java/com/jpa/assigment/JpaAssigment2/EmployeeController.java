package com.jpa.assigment.JpaAssigment2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Array;
import java.util.Arrays;

@Component
public class EmployeeController implements ApplicationRunner {
    @Autowired
    EmployeeRepo employeeRepo;
     @Override
    public void run(ApplicationArguments args) throws Exception {

        Dev employee1 = new Dev();
        employee1.setFirstName("Ayush");
        employee1.setLastName("Thomas");
        employee1.setAge(21);
        employee1.setSalary(50000);


         Hr employee = new Hr();
         employee.setFirstName("highest");
         employee.setLastName("user");
         employee.setAge(50);
         employee.setSalary(100000);

         Dev employee2 = new Dev();
         employee2.setFirstName("Kartik");
         employee2.setLastName("Edison");
         employee2.setAge(24);
         employee2.setSalary(15000);

         Hr employee3 = new Hr();
         employee3.setFirstName("Ayu");
         employee3.setLastName("Singh");
         employee3.setAge(15);
         employee3.setSalary(10000);

        employeeRepo.saveAll(Arrays.asList(employee,employee1,employee2,employee3));
    }
}
