package com.jpa.assigment.JpaAssigment2;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue("dev")
@Table(name = "dev")
@PrimaryKeyJoinColumn(name = "E_id",referencedColumnName = "id")
public class Dev extends Employee {
    private String deptName = "Devlopers";

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
}